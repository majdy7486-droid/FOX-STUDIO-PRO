// Pure Kotlin/JVM module — no Android framework dependency. Only java.io is
// used, so this module's logic can be built and unit-tested with a plain
// JVM + Kotlin toolchain, independent of the Android Gradle Plugin.
plugins {
    id("org.jetbrains.kotlin.jvm")
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
