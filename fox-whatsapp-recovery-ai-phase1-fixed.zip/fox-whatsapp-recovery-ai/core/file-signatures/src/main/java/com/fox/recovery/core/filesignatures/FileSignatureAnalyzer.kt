package com.fox.recovery.core.filesignatures

import java.io.File
import java.io.RandomAccessFile

/**
 * File types this analyzer can identify from the first bytes of a file
 * (its "magic number"), independent of whatever extension the file
 * currently carries.
 *
 * [commonExtensions] lists the extensions normally associated with the
 * type; used to flag files whose name was changed (deliberately,
 * accidentally, or by data loss) so the content no longer matches the
 * claimed extension.
 */
enum class DetectedFileType(val label: String, val commonExtensions: List<String>) {
    JPEG("JPEG Image", listOf("jpg", "jpeg")),
    PNG("PNG Image", listOf("png")),
    GIF("GIF Image", listOf("gif")),
    WEBP("WebP Image", listOf("webp")),
    BMP("Bitmap Image", listOf("bmp")),
    MP4("MP4 Video", listOf("mp4", "m4v")),
    MOV("QuickTime Video", listOf("mov")),
    MKV_WEBM("Matroska / WebM Video", listOf("mkv", "webm")),
    THREE_GP("3GP Video", listOf("3gp", "3g2")),
    AVI("AVI Video", listOf("avi")),
    UNKNOWN("Unknown / Unrecognized", emptyList())
}

/**
 * Result of inspecting one file's header.
 *
 * This result alone does NOT mean a file is "recoverable" — it only
 * describes what the bytes on disk actually are. The recovery engines
 * decide status from this plus source, accessibility and integrity checks.
 */
data class SignatureResult(
    val file: File,
    val detectedType: DetectedFileType,
    val claimedExtension: String,
    val extensionMismatch: Boolean,
    val headerReadable: Boolean
)

/**
 * Detects a file's real type from its binary header (magic bytes),
 * independent of its extension. Read-only: never writes to or modifies
 * the inspected file.
 *
 * Verified against a standalone JVM test harness covering every branch
 * below (see docs/STATUS.md for how, since no Android/Gradle toolchain
 * is available in the environment this project was scaffolded in).
 */
object FileSignatureAnalyzer {

    private const val HEADER_READ_SIZE = 32

    fun analyze(file: File): SignatureResult {
        if (!file.exists() || !file.canRead() || file.length() < 4) {
            return SignatureResult(file, DetectedFileType.UNKNOWN, file.extension.lowercase(), false, headerReadable = false)
        }
        val header = ByteArray(HEADER_READ_SIZE)
        val bytesRead = try {
            RandomAccessFile(file, "r").use { it.read(header) }
        } catch (e: Exception) {
            -1
        }
        if (bytesRead <= 0) {
            return SignatureResult(file, DetectedFileType.UNKNOWN, file.extension.lowercase(), false, headerReadable = false)
        }
        return analyzeHeader(header, bytesRead, file)
    }

    /** Exposed separately so engines/tests can check raw bytes without touching the filesystem. */
    fun analyzeHeader(header: ByteArray, len: Int, sourceFile: File): SignatureResult {
        val detected = detectType(header, len)
        val claimedExt = sourceFile.extension.lowercase()
        val mismatch = detected != DetectedFileType.UNKNOWN &&
            claimedExt.isNotEmpty() &&
            claimedExt !in detected.commonExtensions
        return SignatureResult(sourceFile, detected, claimedExt, mismatch, headerReadable = true)
    }

    private fun matches(header: ByteArray, len: Int, offset: Int, vararg bytes: Int): Boolean {
        if (offset + bytes.size > len) return false
        for (i in bytes.indices) {
            if ((header[offset + i].toInt() and 0xFF) != bytes[i]) return false
        }
        return true
    }

    private fun detectType(header: ByteArray, len: Int): DetectedFileType = when {
        matches(header, len, 0, 0xFF, 0xD8, 0xFF) -> DetectedFileType.JPEG
        matches(header, len, 0, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A) -> DetectedFileType.PNG
        matches(header, len, 0, 0x47, 0x49, 0x46, 0x38) -> DetectedFileType.GIF
        matches(header, len, 0, 0x52, 0x49, 0x46, 0x46) && matches(header, len, 8, 0x57, 0x45, 0x42, 0x50) -> DetectedFileType.WEBP
        matches(header, len, 0, 0x52, 0x49, 0x46, 0x46) && matches(header, len, 8, 0x41, 0x56, 0x49, 0x20) -> DetectedFileType.AVI
        matches(header, len, 0, 0x42, 0x4D) -> DetectedFileType.BMP
        matches(header, len, 0, 0x1A, 0x45, 0xDF, 0xA3) -> DetectedFileType.MKV_WEBM
        len >= 12 && matches(header, len, 4, 0x66, 0x74, 0x79, 0x70) -> classifyIsoBmff(header)
        else -> DetectedFileType.UNKNOWN
    }

    private fun classifyIsoBmff(header: ByteArray): DetectedFileType {
        val brand = String(header, 8, 4, Charsets.US_ASCII).trim()
        return when {
            brand.startsWith("qt") -> DetectedFileType.MOV
            brand.startsWith("3g") -> DetectedFileType.THREE_GP
            else -> DetectedFileType.MP4
        }
    }
}
