package com.fox.recovery.core.filesignatures

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

/**
 * These cases mirror a standalone JVM harness that was run against the
 * same byte-matching algorithm before it was ported into this module
 * (see docs/STATUS.md). Re-running them here with the real Kotlin
 * compiler/Gradle is the next verification step once this project is
 * opened in an environment with the Android/Kotlin toolchain installed.
 */
class FileSignatureAnalyzerTest {

    private fun result(header: ByteArray, claimedName: String) =
        FileSignatureAnalyzer.analyzeHeader(header, header.size, File(claimedName))

    @Test fun detectsRealJpeg() {
        val r = result(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0, 0, 0, 0), "photo.jpg")
        assertEquals(DetectedFileType.JPEG, r.detectedType)
        assertEquals(false, r.extensionMismatch)
    }

    @Test fun detectsPngRenamedAsJpg() {
        val pngHeader = byteArrayOf(
            0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0
        )
        val r = result(pngHeader, "disguised.jpg")
        assertEquals(DetectedFileType.PNG, r.detectedType)
        assertEquals(true, r.extensionMismatch)
    }

    @Test fun detectsGif() {
        val r = result("GIF89a".toByteArray(), "anim.gif")
        assertEquals(DetectedFileType.GIF, r.detectedType)
    }

    @Test fun detectsWebp() {
        val header = ByteArray(16)
        byteArrayOf(0x52, 0x49, 0x46, 0x46).copyInto(header, 0)
        byteArrayOf(0x57, 0x45, 0x42, 0x50).copyInto(header, 8)
        val r = result(header, "sticker.webp")
        assertEquals(DetectedFileType.WEBP, r.detectedType)
    }

    @Test fun detectsMp4() {
        val header = byteArrayOf(0, 0, 0, 0x18, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6F, 0x6D, 0, 0, 0, 0)
        val r = result(header, "clip.mp4")
        assertEquals(DetectedFileType.MP4, r.detectedType)
    }

    @Test fun detectsMovRenamedAsMp4() {
        val header = byteArrayOf(0, 0, 0, 0x14, 0x66, 0x74, 0x79, 0x70, 0x71, 0x74, 0x20, 0x20, 0, 0, 0, 0)
        val r = result(header, "video.mp4")
        assertEquals(DetectedFileType.MOV, r.detectedType)
        assertEquals(true, r.extensionMismatch)
    }

    @Test fun detectsMkvAndWebmFromSameSignature() {
        val header = byteArrayOf(0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte(), 0, 0, 0, 0)
        val mkv = result(header, "movie.mkv")
        val webm = result(header, "movie.webm")
        assertEquals(DetectedFileType.MKV_WEBM, mkv.detectedType)
        assertEquals(false, mkv.extensionMismatch)
        assertEquals(DetectedFileType.MKV_WEBM, webm.detectedType)
        assertEquals(false, webm.extensionMismatch)
    }

    @Test fun unknownForGarbageHeader() {
        val r = result(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8), "mystery.jpg")
        assertEquals(DetectedFileType.UNKNOWN, r.detectedType)
        assertEquals(false, r.extensionMismatch) // never flag a mismatch we can't actually support
    }
}
