# Architecture

MVVM + Repository-flavored layering, matching the spec's required pattern:

```
ui/screens        Compose screens — no business logic, just render state
ui/viewmodel      RecoveryViewModel: exposes StateFlow<ScanProgress>
recovery/         RecoveryCoordinator orchestrates the 4 engines below
  ImageRecoveryEngine    Level 1 (photos)
  VideoRecoveryEngine    Level 1 (videos)
  DeepScanEngine         Level 4 (signature analysis)
  BackupAnalyzer         Level 3 (backup detection, metadata only)
media/            MediaStoreScanner (ContentResolver), WhatsAppPathResolver
core/file-signatures/   Pure Kotlin/JVM module: magic-byte file typing
database/         Room: ScanResultEntity/Dao/Database — persisted history
permissions/      PermissionManager: per-API-level permission logic
```

`core/file-signatures` is deliberately a separate Kotlin/JVM module (not an
Android library) because it only touches `java.io` — keeping it
Android-free means it builds and unit-tests fast, independent of the
Android Gradle Plugin, and could be reused outside Android if ever useful.

Data flows one way: `RecoveryCoordinator.run(kind)` returns a
`Flow<ScanProgress>`; `RecoveryViewModel` collects it into a `StateFlow`,
persists completed results to Room, and screens render whatever state they
observe. No screen talks to an engine directly.
