# Recovery limitations (read before trusting any result)

This app can only act on bytes the Android OS still lets it read. It never
claims otherwise. Concretely:

## What it CAN find
- Photos/videos still physically on the device, whether or not they still
  show up in the gallery or inside WhatsApp (Level 1).
- Files in WhatsApp/WhatsApp Business media folders the OS exposes to any
  app (`Android/media/...`), plus folders the user explicitly grants via
  the Storage Access Framework.
- Files whose real type doesn't match their extension — a renamed or
  partially damaged file whose header is still intact (Level 4).
- The *existence and metadata* of local WhatsApp backup database files.

## What it CANNOT find or do, and says so
- **Content truly erased from storage.** Android does not give normal apps
  access to raw flash/disk sectors, and this app does not attempt any such
  access — that would require root or a forensic imaging tool, which is
  out of scope and explicitly excluded by the spec this was built from.
- **Decrypting WhatsApp's local backups.** `msgstore.db.crypt12/14/15` are
  encrypted with a key WhatsApp does not expose to third-party apps. This
  app detects and reports these files but never attempts to decrypt them.
  Use WhatsApp's own "Restore from backup" flow during reinstall instead.
- **Another app's private storage** (`Android/data/<package>/`), another
  app's own trash/recycle bin, or anything behind the lock screen or
  another app's authentication. Not attempted, not bypassed.
- **A guaranteed success rate.** Every result is shown as one of 8 real
  states (recoverable-from-existing-copy, needs-repair,
  partially-corrupted, unavailable-due-to-permissions, etc.) — never a
  single marketing percentage.

## A note on cloud (Google Drive) backups
WhatsApp's Google Drive backups are restored only through WhatsApp's own
official flow during reinstall, using Google's backup APIs under the
user's own Google account consent. This app does not and will not attempt
to independently access another app's Drive-stored backup; §8 of the spec
asks only that the user be *guided* to the official restore steps, which
is what the (not yet built) help screen will do.
