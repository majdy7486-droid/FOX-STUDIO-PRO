# Privacy & security design notes

- **Local by default.** All scanning in this phase runs entirely on-device.
  No network permission is even declared in the manifest yet (see
  `AndroidManifest.xml` comments) — it will only be added when a specific,
  consent-gated online feature from §8 of the spec is actually built.
- **No broad filesystem access.** The app does not request
  `MANAGE_EXTERNAL_STORAGE`. It uses `MediaStore`, the
  `Android/media/<package>/` shared-media exception (open to all apps even
  under Scoped Storage), and the Storage Access Framework for anything the
  user explicitly picks.
- **No password/key handling implemented.** `BackupAnalyzer` never prompts
  for or stores a WhatsApp backup password or encryption key; it reports
  that decryption is out of scope rather than asking for one.
- **No deletion of originals.** No engine in this codebase deletes,
  overwrites, or mutates a source file. Repairs (once implemented) are
  required by design to write to a separate output path.
- **Scan history minimization.** The Room database stores file metadata
  (name, size, dates, status) needed to show results and history — it does
  not store message content, contact data, or file bytes.
