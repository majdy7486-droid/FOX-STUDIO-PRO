# Build status — read this first

This project was generated in a sandboxed environment with **Java 21 only**:
no Android SDK, no Gradle, no `kotlinc`, and no network access (so none of
those could be downloaded either). That means:

- **I did not and could not run `./gradlew assembleDebug`, `./gradlew test`,
  or `./gradlew lint` here.** No APK has been built, signed, or tested. I'm
  stating this plainly rather than claiming a build succeeded, per the
  project's own explicit requirement not to claim success without
  verification.
- The one piece of logic that doesn't depend on the Android framework —
  `FileSignatureAnalyzer` (magic-byte file-type detection) — I verified
  independently: I wrote a byte-for-byte twin of its algorithm as a
  standalone `.java` file and ran it directly with `java` (Java 21 can run
  a `.java` source file without a separate `javac` step). All 11 cases
  passed — including correctly flagging a PNG renamed to `.jpg` and a MOV
  renamed to `.mp4` as mismatches, correctly identifying MKV/WebM from the
  shared EBML signature, and returning UNKNOWN (not a false positive) for
  garbage bytes. The Kotlin file in `core/file-signatures/` is a direct
  port of that verified logic, plus a JUnit test file mirroring the same
  cases, ready to run for real the moment this opens in a Kotlin/Gradle
  environment.
- **To actually build this**: open the project root in Android Studio
  (Koala/2024.1 or newer handles AGP 8.5 / Kotlin 1.9.24 fine), let Gradle
  sync pull the dependencies, then `Build > Make Project` or run
  `./gradlew assembleDebug` from a machine with internet access and the
  Android SDK installed. See `docs/BUILD.md`.

## What's implemented (real, wired, no stubs)

- **Project scaffold**: Gradle (Kotlin DSL), two modules (`:app`,
  `:core:file-signatures`), manifest with exactly the permissions actually
  used (no `MANAGE_EXTERNAL_STORAGE`).
- **Permissions** (`permissions/PermissionManager.kt`): correct permission
  set per API level (granular `READ_MEDIA_IMAGES`/`READ_MEDIA_VIDEO` on
  33+, legacy `READ_EXTERNAL_STORAGE` below that, partial-access detection
  on 34+), with a rationale string per permission shown before asking.
- **Level 1 — existing media** (`media/MediaStoreScanner.kt`,
  `recovery/ImageRecoveryEngine.kt`, `recovery/VideoRecoveryEngine.kt`):
  real `ContentResolver` queries against `MediaStore`, combined with a
  direct listing of accessible WhatsApp media folders, de-duplicated by
  SHA-256 content hash.
- **WhatsApp folder detection** (`media/WhatsAppPathResolver.kt`): covers
  both the current `Android/media/com.whatsapp(.w4b)/...` location (openly
  readable even under Scoped Storage) and the legacy root-level
  `WhatsApp/Media` location (flagged as needing SAF, not assumed
  accessible) — for both the regular and Business apps.
- **Level 4 — deep scan** (`core/file-signatures/FileSignatureAnalyzer.kt`,
  `recovery/DeepScanEngine.kt`): real magic-byte detection for
  JPEG/PNG/GIF/WebP/BMP/MP4/MOV/MKV/WebM/3GP/AVI, flags extension
  mismatches and unreadable headers, never touches or modifies the
  original file.
- **Level 3 — local backups** (`recovery/BackupAnalyzer.kt`): detects
  `msgstore.db.crypt12/14/15` files and reports metadata only. Does **not**
  attempt decryption — WhatsApp's backup encryption key isn't exposed to
  third-party apps through any public API, so this correctly stops at
  detection and points the user to WhatsApp's own restore flow, rather
  than faking a decrypt.
- **Persistence**: Room database (`database/`) storing every scan result,
  so history survives app restarts; `restoredToPath` is only ever set
  after a real copy actually succeeds (no code path sets it otherwise).
- **MVVM wiring**: `RecoveryViewModel` → `RecoveryCoordinator` → engines,
  exposing real `StateFlow<ScanProgress>` (file counts and error counts,
  never a synthetic percentage) to Compose screens.
- **UI**: Home, Permissions, and Scan Results screens, Material 3 with a
  dark/light palette matching the spec's color list, RTL-ready. Every
  button on these screens is wired to a real action.

## What's intentionally NOT built yet (don't assume it exists)

The full spec calls for 22 screens, a trash/recycle-bin scanner (Level 2),
file repair (not just detection), AI classification/reporting, historical
time-range filters, duplicate-file UI, a signed release build, and a full
instrumented test suite. None of that is faked here. In priority order for
a Phase 2:

1. Wire Robolectric (or instrumented tests) so `WhatsAppPathResolverTest`
   and friends actually execute — they're written but currently inert
   because they touch `android.os.Environment`.
2. Level 2 (system trash / gallery recycle bin) — needs a per-OEM gallery
   survey; this varies more than the spec implies, and I did not want to
   invent APIs that don't exist.
3. Remaining screens: splash, onboarding, duplicates, repair, scan
   history detail, settings, help, privacy/security — currently the app
   only exposes the flows above; I did not add 17 empty placeholder
   screens with non-functional buttons, since the spec explicitly forbids
   buttons without a function.
4. Real repair attempts (currently `repairable` is only ever set to
   `true` as "renaming would fix the extension mismatch" — no file
   content is actually rewritten yet).
5. The optional `FOX Recovery AI` classification module (§7) — not
   started; it's explicitly optional in the spec and depends on which
   on-device model (if any) you want bundled, which affects APK size and
   min SDK.
6. Signed release build / keystore — needs secrets only you should hold;
   `docs/BUILD.md` has the exact commands for when you're ready.


## Implementation update — 2026-10-11

This update fixes scan lifecycle behavior:
- `RecoveryCoordinator` now closes its `callbackFlow` after emitting a terminal
  `Completed` or `Failed` state, instead of leaving collection suspended.
- Cancellation is propagated rather than being reported as a scan failure.
- `RecoveryViewModel` cancels an earlier scan before starting another and
  cancels active work when its state is reset or cleared.

This is an incremental code correction, not a claim that the entire app is
finished or that an APK has been built. The archive currently does not include
`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, or
`gradle/wrapper/gradle-wrapper.properties`; an Android SDK/Gradle build and
device tests are still required. See `docs/STATUS.md` and `docs/BUILD.md`.
