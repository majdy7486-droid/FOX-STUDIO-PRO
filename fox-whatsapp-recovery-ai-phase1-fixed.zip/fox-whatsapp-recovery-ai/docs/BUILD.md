# Building this project

This project has **not** been built or tested in the environment it was
generated in — that environment has Java 21 but no Android SDK, no
Gradle, and no network access (see `docs/STATUS.md`). To build it for
real:

1. Install Android Studio (Koala / 2024.1+) or a standalone Android SDK +
   command-line tools with API 34 installed.
2. Open this project's root folder (the one with `settings.gradle.kts`).
3. Let Gradle sync — it will download AGP 8.5.2, Kotlin 1.9.24, and the
   dependencies listed in `app/build.gradle.kts`.
4. Debug build: `./gradlew assembleDebug` (or Android Studio's Run button
   on a device/emulator with API 26+).
5. Unit tests: `./gradlew test` — run and read the actual output; don't
   assume it passes.
6. Lint: `./gradlew lint`.

## Signed release build (when you're ready)
```
keytool -genkey -v -keystore fox-recovery-release.keystore \
  -alias fox_recovery -keyalg RSA -keysize 2048 -validity 10000
```
Add a `signingConfigs { release { ... } }` block to
`app/build.gradle.kts` referencing that keystore (keep the keystore and
its passwords out of version control — e.g. via `local.properties` or
environment variables), then:
```
./gradlew assembleRelease
```
