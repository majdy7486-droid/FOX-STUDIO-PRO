package com.fox.recovery.recovery

import android.content.Context
import com.fox.recovery.core.filesignatures.DetectedFileType
import com.fox.recovery.core.filesignatures.FileSignatureAnalyzer
import com.fox.recovery.media.MediaStoreScanner
import com.fox.recovery.media.WhatsAppPathResolver
import com.fox.recovery.model.MediaKind
import com.fox.recovery.model.RecoverySource
import com.fox.recovery.model.RecoveryStatus
import com.fox.recovery.model.ScanResultItem
import java.io.File
import java.security.MessageDigest
import java.util.UUID

private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")

/**
 * Level 1 image recovery: combines what MediaStore already indexes with a
 * direct listing of accessible WhatsApp image folders (some files get
 * written there without always being picked up by the MediaStore index
 * promptly), de-duplicated by content hash.
 */
class ImageRecoveryEngine(private val context: Context) {

    private val mediaStoreScanner = MediaStoreScanner(context)

    fun scan(onFile: (Int) -> Unit = {}): List<ScanResultItem> {
        val fromMediaStore = mediaStoreScanner.scanImages(whatsAppOnly = false, onFile = onFile)
        val seenHashes = fromMediaStore.mapNotNull { hashOfUriQuietly(it.absolutePathOrUri) }.toMutableSet()

        val fromFolders = mutableListOf<ScanResultItem>()
        var processed = fromMediaStore.size
        WhatsAppPathResolver.resolveAccessibleCandidates().forEach { dir ->
            dir.listFiles { f -> f.isFile && f.extension.lowercase() in IMAGE_EXTENSIONS }?.forEach { file ->
                val hash = hashOfFileQuietly(file)
                if (hash != null && hash in seenHashes) return@forEach // duplicate of a MediaStore-known file
                hash?.let { seenHashes += it }

                val signature = FileSignatureAnalyzer.analyze(file)
                fromFolders += buildResultItem(file, signature)
                processed++
                onFile(processed)
            }
        }
        return fromMediaStore + fromFolders
    }

    private fun buildResultItem(file: File, signature: com.fox.recovery.core.filesignatures.SignatureResult): ScanResultItem {
        val status = when {
            !signature.headerReadable -> RecoveryStatus.UNVERIFIABLE
            signature.detectedType == DetectedFileType.UNKNOWN -> RecoveryStatus.PARTIALLY_CORRUPTED
            else -> RecoveryStatus.EXISTS_CAN_BE_COPIED
        }
        return ScanResultItem(
            id = UUID.randomUUID().toString(),
            displayName = file.name,
            kind = MediaKind.IMAGE,
            sizeBytes = file.length(),
            source = RecoverySource.EXISTING_WHATSAPP_FOLDER,
            dateAvailable = file.lastModified(),
            status = status,
            previewAvailable = signature.headerReadable,
            repairable = false,
            unavailableReason = if (status == RecoveryStatus.PARTIALLY_CORRUPTED)
                "File header does not match a known image format (name: .${signature.claimedExtension})" else null,
            absolutePathOrUri = file.absolutePath
        )
    }

    private fun hashOfFileQuietly(file: File): String? = try {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            var read: Int
            while (input.read(buffer).also { read = it } != -1) digest.update(buffer, 0, read)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { null }

    private fun hashOfUriQuietly(uriString: String): String? = try {
        val uri = android.net.Uri.parse(uriString)
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(8192)
            var read: Int
            while (input.read(buffer).also { read = it } != -1) digest.update(buffer, 0, read)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { null }
}
