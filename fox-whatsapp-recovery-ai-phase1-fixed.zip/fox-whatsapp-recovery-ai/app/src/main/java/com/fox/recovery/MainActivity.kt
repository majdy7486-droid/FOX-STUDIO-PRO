package com.fox.recovery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.fox.recovery.navigation.FoxNavGraph
import com.fox.recovery.ui.theme.FoxRecoveryTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FoxRecoveryTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FoxNavGraph()
                }
            }
        }
    }
}
