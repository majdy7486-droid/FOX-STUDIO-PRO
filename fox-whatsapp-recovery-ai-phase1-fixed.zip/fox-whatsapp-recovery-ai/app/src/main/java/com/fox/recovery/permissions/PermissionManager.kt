package com.fox.recovery.permissions

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Centralizes the permission set this app actually needs — and nothing more.
 *
 * Deliberately does NOT request MANAGE_EXTERNAL_STORAGE. Media scanning uses
 * MediaStore + the Android/media/ shared-media path (open to all apps even
 * under Scoped Storage) + the Storage Access Framework for anything else the
 * user explicitly picks. See docs/PRIVACY.md for the reasoning.
 */
object PermissionManager {

    /** The runtime permission(s) this device actually needs to grant, by API level. */
    fun requiredMediaPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
            android.Manifest.permission.READ_MEDIA_IMAGES,
            android.Manifest.permission.READ_MEDIA_VIDEO
        )
        else -> arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    fun hasMediaPermissions(context: Context): Boolean =
        requiredMediaPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

    /**
     * Android 14+ can grant "partial" photo/video access (user picks specific
     * items) instead of full access. We can still operate, but should tell
     * the user their results may be incomplete.
     */
    fun hasPartialMediaAccessOnly(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 34) return false
        val readImages = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.READ_MEDIA_IMAGES
        ) == PackageManager.PERMISSION_GRANTED
        val partial = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        ) == PackageManager.PERMISSION_GRANTED
        return !readImages && partial
    }

    /** Human-readable reason for each permission, shown on the rationale screen — never hidden. */
    fun rationaleFor(permission: String): String = when (permission) {
        android.Manifest.permission.READ_MEDIA_IMAGES ->
            "Needed to list and preview photos that may be recoverable."
        android.Manifest.permission.READ_MEDIA_VIDEO ->
            "Needed to list and preview videos that may be recoverable."
        android.Manifest.permission.READ_EXTERNAL_STORAGE ->
            "Needed on this Android version to read photo and video files on the device."
        else -> "Needed for this scan to see the relevant files."
    }
}
