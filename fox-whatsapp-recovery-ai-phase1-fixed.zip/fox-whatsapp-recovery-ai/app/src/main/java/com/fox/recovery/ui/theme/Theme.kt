package com.fox.recovery.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette per spec section 9: dark black, professional blue, purple, white, clear grays.
private val FoxBlue = Color(0xFF2962FF)
private val FoxPurple = Color(0xFF6A4CFF)
private val FoxDarkBg = Color(0xFF0E0F13)
private val FoxSurfaceDark = Color(0xFF17181F)

private val DarkColors = darkColorScheme(
    primary = FoxBlue,
    secondary = FoxPurple,
    background = FoxDarkBg,
    surface = FoxSurfaceDark,
    onPrimary = Color.White,
    onBackground = Color(0xFFE6E6EA),
    onSurface = Color(0xFFE6E6EA)
)

private val LightColors = lightColorScheme(
    primary = FoxBlue,
    secondary = FoxPurple,
    background = Color.White,
    surface = Color(0xFFF4F5F8),
    onPrimary = Color.White,
    onBackground = Color(0xFF17181F),
    onSurface = Color(0xFF17181F)
)

@Composable
fun FoxRecoveryTheme(
    useDarkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (useDarkTheme) DarkColors else LightColors,
        content = content
    )
}
