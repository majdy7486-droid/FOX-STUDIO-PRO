package com.fox.recovery.recovery

import android.content.Context
import com.fox.recovery.media.WhatsAppPathResolver
import com.fox.recovery.model.ScanProgress
import com.fox.recovery.model.ScanResultItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

/** Which real scan a caller is asking for — each maps to one spec'd recovery level/screen. */
enum class ScanKind { IMAGES, VIDEOS, WHATSAPP_DEEP_SCAN, LOCAL_BACKUPS }

/**
 * Runs one real scan at a time and reports genuine progress (files
 * processed, errors hit) — never a synthetic percentage. All work runs on
 * Dispatchers.IO; this class does no UI work itself.
 */
class RecoveryCoordinator(private val context: Context) {

    private val imageEngine = ImageRecoveryEngine(context)
    private val videoEngine = VideoRecoveryEngine(context)
    private val deepScanEngine = DeepScanEngine()
    private val backupAnalyzer = BackupAnalyzer()

    fun run(kind: ScanKind): Flow<ScanProgress> = callbackFlow {
        trySend(ScanProgress.Running(sourceLabel(kind), 0, 0))
        var errors = 0
        try {
            val results: List<ScanResultItem> = withContext(Dispatchers.IO) {
                when (kind) {
                    ScanKind.IMAGES -> imageEngine.scan { processed ->
                        trySend(ScanProgress.Running(sourceLabel(kind), processed, errors))
                    }
                    ScanKind.VIDEOS -> videoEngine.scan { processed ->
                        trySend(ScanProgress.Running(sourceLabel(kind), processed, errors))
                    }
                    ScanKind.WHATSAPP_DEEP_SCAN -> {
                        val roots = WhatsAppPathResolver.resolveAccessibleCandidates()
                        if (roots.isEmpty()) {
                            emptyList()
                        } else {
                            deepScanEngine.scan(roots) { processed ->
                                trySend(ScanProgress.Running(sourceLabel(kind), processed, errors))
                            }
                        }
                    }
                    ScanKind.LOCAL_BACKUPS -> {
                        // Metadata-only; not a file-by-file scan, so report as a single step.
                        val report = backupAnalyzer.analyze()
                        trySend(ScanProgress.Running(sourceLabel(kind), 1, 0))
                        report.localBackupsFound.map { backup ->
                            com.fox.recovery.model.ScanResultItem(
                                id = backup.file.absolutePath,
                                displayName = backup.file.name,
                                kind = com.fox.recovery.model.MediaKind.DOCUMENT,
                                sizeBytes = backup.sizeBytes,
                                source = com.fox.recovery.model.RecoverySource.LOCAL_BACKUP,
                                dateAvailable = backup.lastModified,
                                status = com.fox.recovery.model.RecoveryStatus.UNVERIFIABLE,
                                previewAvailable = false,
                                repairable = false,
                                unavailableReason = report.limitationMessage,
                                absolutePathOrUri = backup.file.absolutePath
                            )
                        }
                    }
                }
            }
            trySend(ScanProgress.Completed(results, results.size, errors))
            close()
        } catch (e: kotlinx.coroutines.CancellationException) {
            // Propagate cancellation so a stopped scan does not keep consuming resources.
            throw e
        } catch (e: Exception) {
            errors++
            trySend(ScanProgress.Failed(e.message ?: "Unknown error during scan"))
            close()
        }
        awaitClose { }
    }

    private fun sourceLabel(kind: ScanKind): String = when (kind) {
        ScanKind.IMAGES -> "Photos"
        ScanKind.VIDEOS -> "Videos"
        ScanKind.WHATSAPP_DEEP_SCAN -> "WhatsApp folders (deep scan)"
        ScanKind.LOCAL_BACKUPS -> "Local backups"
    }
}
