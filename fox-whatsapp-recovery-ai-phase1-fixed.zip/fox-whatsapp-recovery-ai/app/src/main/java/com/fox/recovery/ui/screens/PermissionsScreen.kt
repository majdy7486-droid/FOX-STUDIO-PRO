package com.fox.recovery.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.fox.recovery.permissions.PermissionManager

/**
 * Real rationale, shown before the OS permission dialog — never hidden or
 * skipped, per spec ("توضيح الصلاحيات المستخدمة وأسباب طلبها").
 */
@Composable
fun PermissionsScreen(onGranted: () -> Unit) {
    val context = LocalContext.current
    val required = remember { PermissionManager.requiredMediaPermissions() }
    var denied by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) onGranted() else denied = true
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Why this permission is needed", style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
        required.forEach { permission ->
            Text("• " + PermissionManager.rationaleFor(permission), modifier = Modifier.padding(top = 8.dp))
        }
        if (denied) {
            Text(
                "Without this permission the app cannot scan for recoverable media. You can grant it from the system Settings at any time.",
                modifier = Modifier.padding(top = 16.dp)
            )
        }
        Button(onClick = { launcher.launch(required) }, modifier = Modifier.padding(top = 24.dp)) {
            Text(if (denied) "Try again" else "Grant access")
        }
    }
}
