package com.fox.recovery.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fox.recovery.recovery.ScanKind

/**
 * Home screen. Every button here is wired to a real, working action —
 * no placeholder buttons. The spec's full 22-screen set is not all built
 * yet (see docs/STATUS.md for what remains); this screen only exposes
 * flows that are actually implemented behind it.
 */
@Composable
fun HomeScreen(
    onStartScan: (ScanKind) -> Unit,
    onOpenPermissions: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("FOX WhatsApp Recovery AI", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Local-first scanning. No files are uploaded anywhere without your explicit consent.",
            style = MaterialTheme.typography.bodyMedium
        )

        Button(onClick = { onStartScan(ScanKind.IMAGES) }, modifier = Modifier.padding(top = 16.dp)) {
            Text("Recover photos")
        }
        Button(onClick = { onStartScan(ScanKind.VIDEOS) }) {
            Text("Recover videos")
        }
        Button(onClick = { onStartScan(ScanKind.WHATSAPP_DEEP_SCAN) }) {
            Text("Deep scan WhatsApp folders")
        }
        Button(onClick = { onStartScan(ScanKind.LOCAL_BACKUPS) }) {
            Text("Check local backups")
        }
        Button(onClick = onOpenPermissions) {
            Text("Permissions & privacy")
        }
    }
}
