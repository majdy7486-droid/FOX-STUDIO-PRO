package com.fox.recovery.model

/** Where a candidate file was found. Drives how it's displayed and what "restore" does. */
enum class RecoverySource {
    EXISTING_MEDIA_STORE,      // Level 1: still present, indexed by MediaStore
    EXISTING_WHATSAPP_FOLDER,  // Level 1: still present in a WhatsApp media folder
    SYSTEM_TRASH,              // Level 2: gallery/file-manager trash the OS exposes
    LOCAL_BACKUP,              // Level 3: extracted from a local WhatsApp backup
    DEEP_SCAN                  // Level 4: found by signature analysis, no longer in any index
}

/** Mirrors the eight result states required by the spec (docs/RECOVERY_LIMITATIONS.md). */
enum class RecoveryStatus {
    RECOVERABLE_FROM_EXISTING_COPY,
    EXISTS_CAN_BE_COPIED,
    EXTRACTED_FROM_BACKUP,
    NEEDS_REPAIR,
    PARTIALLY_CORRUPTED,
    UNVERIFIABLE,
    UNAVAILABLE_PERMISSIONS,
    NOT_FOUND_IN_SCANNED_SOURCES
}

enum class MediaKind { IMAGE, VIDEO, AUDIO, DOCUMENT, OTHER }

data class ScanResultItem(
    val id: String,
    val displayName: String,
    val kind: MediaKind,
    val sizeBytes: Long,
    val source: RecoverySource,
    val dateAvailable: Long?,        // epoch millis; null if unknown
    val status: RecoveryStatus,
    val previewAvailable: Boolean,
    val repairable: Boolean,
    val unavailableReason: String?,  // populated only when status explains why it can't be restored
    val absolutePathOrUri: String
)

/** Real, incremental progress — never a synthetic percentage (no fake progress bars). */
sealed class ScanProgress {
    data object Idle : ScanProgress()
    data class Running(val sourceLabel: String, val filesProcessed: Int, val errors: Int) : ScanProgress()
    data class Completed(val results: List<ScanResultItem>, val filesProcessed: Int, val errors: Int) : ScanProgress()
    data class Failed(val reason: String) : ScanProgress()
}
