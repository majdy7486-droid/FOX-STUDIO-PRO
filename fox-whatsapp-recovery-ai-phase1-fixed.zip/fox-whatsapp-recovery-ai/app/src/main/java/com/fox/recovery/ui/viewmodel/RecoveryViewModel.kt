package com.fox.recovery.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fox.recovery.database.RecoveryDatabase
import com.fox.recovery.database.toEntity
import com.fox.recovery.model.ScanProgress
import com.fox.recovery.recovery.RecoveryCoordinator
import com.fox.recovery.recovery.ScanKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch\nimport kotlinx.coroutines.Job\nimport kotlinx.coroutines.cancelAndJoin

/**
 * Single ViewModel the three scan screens share (MVVM, per the project's
 * required architecture). Holds real, observable scan state — no fake
 * loading state kept around after a scan actually finishes or fails.
 */
class RecoveryViewModel(application: Application) : AndroidViewModel(application) {

    private val coordinator = RecoveryCoordinator(application)
    private val dao = RecoveryDatabase.getInstance(application).scanResultDao()
    private var scanJob: Job? = null

    private val _progress = MutableStateFlow<ScanProgress>(ScanProgress.Idle)
    val progress: StateFlow<ScanProgress> = _progress.asStateFlow()

    fun startScan(kind: ScanKind) {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            coordinator.run(kind).collect { update ->
                _progress.value = update
                if (update is ScanProgress.Completed && update.results.isNotEmpty()) {
                    val timestamp = System.currentTimeMillis()
                    dao.insertAll(update.results.map { it.toEntity(timestamp) })
                }
            }
        }
    }

    fun resetState() {
        scanJob?.cancel()
        scanJob = null
        _progress.value = ScanProgress.Idle
    }

    override fun onCleared() {
        scanJob?.cancel()
        super.onCleared()
    }
}
