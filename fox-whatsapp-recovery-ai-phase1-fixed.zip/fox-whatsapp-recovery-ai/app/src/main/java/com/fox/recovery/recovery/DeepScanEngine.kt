package com.fox.recovery.recovery

import com.fox.recovery.core.filesignatures.DetectedFileType
import com.fox.recovery.core.filesignatures.FileSignatureAnalyzer
import com.fox.recovery.model.MediaKind
import com.fox.recovery.model.RecoverySource
import com.fox.recovery.model.RecoveryStatus
import com.fox.recovery.model.ScanResultItem
import java.io.File
import java.util.UUID

/**
 * Level 4 "deep scan": signature-based inspection of accessible folders
 * (never raw disk sectors — see docs/RECOVERY_LIMITATIONS.md for why that's
 * out of scope on unrooted Android). Finds files whose real content doesn't
 * match their extension, and flags unreadable/corrupted headers.
 *
 * This does NOT recover data that is truly gone from the filesystem; it can
 * only re-identify and re-classify bytes that are still present somewhere
 * the app is allowed to read.
 */
class DeepScanEngine {

    fun scan(roots: List<File>, onFile: (Int) -> Unit = {}): List<ScanResultItem> {
        val results = mutableListOf<ScanResultItem>()
        var processed = 0

        roots.forEach { root ->
            walk(root).forEach { file ->
                val signature = FileSignatureAnalyzer.analyze(file)
                if (signature.detectedType != DetectedFileType.UNKNOWN || !signature.headerReadable) {
                    results += toResultItem(file, signature)
                }
                processed++
                onFile(processed)
            }
        }
        return results
    }

    private fun walk(dir: File): Sequence<File> = sequence {
        val stack = ArrayDeque<File>()
        stack.addLast(dir)
        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            val children = current.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) stack.addLast(child) else yield(child)
            }
        }
    }

    private fun toResultItem(file: File, signature: com.fox.recovery.core.filesignatures.SignatureResult): ScanResultItem {
        val kind = when (signature.detectedType) {
            DetectedFileType.JPEG, DetectedFileType.PNG, DetectedFileType.GIF,
            DetectedFileType.WEBP, DetectedFileType.BMP -> MediaKind.IMAGE
            DetectedFileType.MP4, DetectedFileType.MOV, DetectedFileType.MKV_WEBM,
            DetectedFileType.THREE_GP, DetectedFileType.AVI -> MediaKind.VIDEO
            DetectedFileType.UNKNOWN -> MediaKind.OTHER
        }
        val status = when {
            !signature.headerReadable -> RecoveryStatus.UNVERIFIABLE
            signature.extensionMismatch -> RecoveryStatus.NEEDS_REPAIR // real type found, name is wrong/misleading
            else -> RecoveryStatus.EXISTS_CAN_BE_COPIED
        }
        val reason = when {
            !signature.headerReadable -> "File could not be read to verify its contents."
            signature.extensionMismatch -> "File extension (.${signature.claimedExtension}) does not match detected content (${signature.detectedType.label})."
            else -> null
        }
        return ScanResultItem(
            id = UUID.randomUUID().toString(),
            displayName = file.name,
            kind = kind,
            sizeBytes = file.length(),
            source = RecoverySource.DEEP_SCAN,
            dateAvailable = file.lastModified(),
            status = status,
            previewAvailable = signature.headerReadable && kind != MediaKind.OTHER,
            repairable = signature.extensionMismatch, // renaming to the correct extension is a safe, real "repair"
            unavailableReason = reason,
            absolutePathOrUri = file.absolutePath
        )
    }
}
