package com.fox.recovery

import android.app.Application

class FoxRecoveryApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Intentionally no analytics/crash-reporting SDK wired up yet: the
        // spec requires explicit consent before any network call, and none
        // of the optional online features (§8) are implemented in this
        // phase. See docs/PRIVACY.md.
    }
}
