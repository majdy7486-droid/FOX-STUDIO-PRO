package com.fox.recovery.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fox.recovery.model.ScanProgress

/**
 * Shows real progress (files processed so far, errors) while a scan runs,
 * then the real result list. No simulated percentage — spec explicitly
 * forbids a fake progress bar.
 */
@Composable
fun ScanResultsScreen(progress: ScanProgress) {
    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        when (progress) {
            is ScanProgress.Idle -> Text("Starting scan…")

            is ScanProgress.Running -> {
                Row(progress.sourceLabel, progress.filesProcessed, progress.errors)
            }

            is ScanProgress.Completed -> {
                Text(
                    "${progress.results.size} item(s) found · ${progress.errors} error(s)",
                    style = MaterialTheme.typography.titleMedium
                )
                LazyColumn(modifier = Modifier.padding(top = 12.dp)) {
                    items(progress.results) { item ->
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            Text(item.displayName, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "${item.status.name} · ${item.sizeBytes / 1024} KB · ${item.source.name}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            item.unavailableReason?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            is ScanProgress.Failed -> {
                Text("Scan failed: ${progress.reason}", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
private fun Row(sourceLabel: String, filesProcessed: Int, errors: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        CircularProgressIndicator()
        Text("Scanning: $sourceLabel")
        Text("Files processed: $filesProcessed    Errors: $errors")
    }
}
