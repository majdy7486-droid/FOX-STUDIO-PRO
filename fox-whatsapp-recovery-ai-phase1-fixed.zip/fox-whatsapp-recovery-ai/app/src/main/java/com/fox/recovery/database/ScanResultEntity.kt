package com.fox.recovery.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.fox.recovery.model.MediaKind
import com.fox.recovery.model.RecoverySource
import com.fox.recovery.model.RecoveryStatus
import com.fox.recovery.model.ScanResultItem

/**
 * Persisted scan results, so "scan history" and "recovered files" survive
 * app restarts. Enums are stored as their name (String) — simplest reliable
 * Room mapping, avoids needing custom TypeConverters for this phase.
 */
@Entity(tableName = "scan_results")
data class ScanResultEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val kind: String,
    val sizeBytes: Long,
    val source: String,
    val dateAvailable: Long?,
    val status: String,
    val previewAvailable: Boolean,
    val repairable: Boolean,
    val unavailableReason: String?,
    val absolutePathOrUri: String,
    val scanTimestamp: Long,
    val restoredToPath: String? = null // set only after a real, verified restore — see RECOVERY_LIMITATIONS.md
)

fun ScanResultItem.toEntity(scanTimestamp: Long): ScanResultEntity = ScanResultEntity(
    id = id,
    displayName = displayName,
    kind = kind.name,
    sizeBytes = sizeBytes,
    source = source.name,
    dateAvailable = dateAvailable,
    status = status.name,
    previewAvailable = previewAvailable,
    repairable = repairable,
    unavailableReason = unavailableReason,
    absolutePathOrUri = absolutePathOrUri,
    scanTimestamp = scanTimestamp
)

fun ScanResultEntity.toModel(): ScanResultItem = ScanResultItem(
    id = id,
    displayName = displayName,
    kind = MediaKind.valueOf(kind),
    sizeBytes = sizeBytes,
    source = RecoverySource.valueOf(source),
    dateAvailable = dateAvailable,
    status = RecoveryStatus.valueOf(status),
    previewAvailable = previewAvailable,
    repairable = repairable,
    unavailableReason = unavailableReason,
    absolutePathOrUri = absolutePathOrUri
)
