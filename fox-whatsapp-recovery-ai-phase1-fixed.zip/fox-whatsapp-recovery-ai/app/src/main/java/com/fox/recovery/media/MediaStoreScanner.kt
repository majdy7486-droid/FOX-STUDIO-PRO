package com.fox.recovery.media

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.fox.recovery.model.MediaKind
import com.fox.recovery.model.RecoverySource
import com.fox.recovery.model.RecoveryStatus
import com.fox.recovery.model.ScanResultItem
import java.util.UUID

/**
 * Level 1 recovery: media that still physically exists and is indexed by
 * MediaStore, but the user can no longer find it (removed from an album,
 * hidden by a ".nomedia" change, etc.). This does real ContentResolver
 * queries — no mock/sample data.
 */
class MediaStoreScanner(private val context: Context) {

    /**
     * @param whatsAppOnly when true, only returns items whose RELATIVE_PATH
     * contains a WhatsApp folder name; when false, returns all images/videos
     * (used by the general "existing media" scan).
     */
    fun scanImages(whatsAppOnly: Boolean, onFile: (Int) -> Unit = {}): List<ScanResultItem> =
        scanCollection(
            collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            kind = MediaKind.IMAGE,
            whatsAppOnly = whatsAppOnly,
            onFile = onFile
        )

    fun scanVideos(whatsAppOnly: Boolean, onFile: (Int) -> Unit = {}): List<ScanResultItem> =
        scanCollection(
            collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            kind = MediaKind.VIDEO,
            whatsAppOnly = whatsAppOnly,
            onFile = onFile
        )

    private fun scanCollection(
        collection: android.net.Uri,
        kind: MediaKind,
        whatsAppOnly: Boolean,
        onFile: (Int) -> Unit
    ): List<ScanResultItem> {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.RELATIVE_PATH
        )

        val (selection, args) = if (whatsAppOnly) {
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?" to arrayOf("%WhatsApp%")
        } else {
            null to null
        }

        val results = mutableListOf<ScanResultItem>()
        var processed = 0

        context.contentResolver.query(
            collection, projection, selection, args,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val relativePath = cursor.getString(pathCol) ?: ""
                val source = if (relativePath.contains("WhatsApp", ignoreCase = true)) {
                    RecoverySource.EXISTING_WHATSAPP_FOLDER
                } else {
                    RecoverySource.EXISTING_MEDIA_STORE
                }

                results += ScanResultItem(
                    id = UUID.randomUUID().toString(),
                    displayName = cursor.getString(nameCol) ?: "unknown",
                    kind = kind,
                    sizeBytes = cursor.getLong(sizeCol),
                    source = source,
                    dateAvailable = cursor.getLong(dateCol) * 1000L,
                    status = RecoveryStatus.EXISTS_CAN_BE_COPIED,
                    previewAvailable = true,
                    repairable = false,
                    unavailableReason = null,
                    absolutePathOrUri = uri.toString()
                )
                processed++
                onFile(processed)
            }
        }
        return results
    }
}
