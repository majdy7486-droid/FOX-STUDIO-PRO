package com.fox.recovery.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanResultDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(results: List<ScanResultEntity>)

    @Query("SELECT * FROM scan_results ORDER BY scanTimestamp DESC")
    fun observeAll(): Flow<List<ScanResultEntity>>

    @Query("SELECT * FROM scan_results WHERE source = :source ORDER BY scanTimestamp DESC")
    fun observeBySource(source: String): Flow<List<ScanResultEntity>>

    @Query("SELECT DISTINCT scanTimestamp FROM scan_results ORDER BY scanTimestamp DESC")
    suspend fun scanHistoryTimestamps(): List<Long>

    @Query("DELETE FROM scan_results")
    suspend fun clearAll()

    @Query("UPDATE scan_results SET restoredToPath = :destinationPath WHERE id = :id")
    suspend fun markRestored(id: String, destinationPath: String)
}
