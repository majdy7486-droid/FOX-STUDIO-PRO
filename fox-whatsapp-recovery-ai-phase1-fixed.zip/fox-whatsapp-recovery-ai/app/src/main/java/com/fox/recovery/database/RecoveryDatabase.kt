package com.fox.recovery.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ScanResultEntity::class], version = 1, exportSchema = true)
abstract class RecoveryDatabase : RoomDatabase() {

    abstract fun scanResultDao(): ScanResultDao

    companion object {
        @Volatile private var instance: RecoveryDatabase? = null

        fun getInstance(context: Context): RecoveryDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    RecoveryDatabase::class.java,
                    "fox_recovery.db"
                ).build().also { instance = it }
            }
    }
}
