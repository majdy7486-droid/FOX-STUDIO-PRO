package com.fox.recovery.media

import android.os.Environment
import java.io.File

/** Which WhatsApp variant a candidate path belongs to. */
enum class WhatsAppVariant { REGULAR, BUSINESS }

/**
 * One known on-disk location WhatsApp (or WhatsApp Business) may have used
 * for media, across Android versions and WhatsApp's own storage migration.
 *
 * [directAccessExpected] = true means plain java.io.File access should work
 * without the user picking the folder (true for the Android/media/ shared
 * path, and for legacy paths on API < 30 once the legacy permission is
 * granted). false means the folder is expected to need the Storage Access
 * Framework (SAF) folder picker on this device/Android version — the
 * resolver reports it as a candidate either way and lets the caller try
 * direct access first, falling back to "ask the user to pick it via SAF."
 */
data class WhatsAppMediaPath(
    val variant: WhatsAppVariant,
    val relativePath: String,
    val directAccessExpected: Boolean
)

/**
 * Resolves the set of folders that MIGHT contain WhatsApp media on this
 * device. Never assumes a fixed path is guaranteed to exist or be
 * accessible — every entry must still be checked (exists() / SAF listing)
 * before being trusted. See spec requirement: "don't rely on fixed paths
 * only; folder layout differs across devices and versions."
 */
object WhatsAppPathResolver {

    private val knownRelativePaths: List<WhatsAppMediaPath> = listOf(
        // Current location since WhatsApp migrated off the legacy root folder.
        // Android/media/<pkg>/ is readable by any app without extra permission
        // even under Scoped Storage — this is the most reliable candidate.
        WhatsAppMediaPath(WhatsAppVariant.REGULAR, "Android/media/com.whatsapp/WhatsApp/Media", directAccessExpected = true),
        WhatsAppMediaPath(WhatsAppVariant.BUSINESS, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media", directAccessExpected = true),

        // Legacy root-level folder. Still present on upgraded installs / older
        // Android versions. Direct File access to this is unreliable once
        // Scoped Storage is enforced (API 30+) unless the app has the legacy
        // storage permission flag honored — treat as SAF-required there.
        WhatsAppMediaPath(WhatsAppVariant.REGULAR, "WhatsApp/Media", directAccessExpected = false),
        WhatsAppMediaPath(WhatsAppVariant.BUSINESS, "WhatsApp Business/Media", directAccessExpected = false)
    )

    private val mediaSubfolders = listOf(
        "WhatsApp Images", "WhatsApp Video", "WhatsApp Audio",
        "WhatsApp Documents", "WhatsApp Animated Gifs", "WhatsApp Stickers",
        "WhatsApp Images/Sent", "WhatsApp Video/Sent"
    )

    /**
     * Returns every (base path × subfolder) combination as an absolute File,
     * WITHOUT checking existence — callers decide direct-access vs SAF
     * per [WhatsAppMediaPath.directAccessExpected] and must still verify
     * accessibility themselves (see [resolveAccessibleCandidates]).
     */
    fun allCandidatePaths(): List<Pair<WhatsAppMediaPath, File>> {
        val root = Environment.getExternalStorageDirectory()
        return knownRelativePaths.flatMap { base ->
            mediaSubfolders.map { sub ->
                base to File(root, "${base.relativePath}/$sub")
            }
        }
    }

    /**
     * Filters candidates down to ones that direct File access can actually
     * see right now on this device. Candidates marked SAF-required, or that
     * simply don't exist/aren't readable, are left out — the caller should
     * separately prompt for SAF access to cover those, rather than silently
     * treating "not found" as "doesn't exist."
     */
    fun resolveAccessibleCandidates(): List<File> =
        allCandidatePaths()
            .filter { (base, _) -> base.directAccessExpected }
            .map { (_, file) -> file }
            .filter { it.exists() && it.isDirectory && it.canRead() }

    /** Base folders that likely need the user to grant access via SAF (not directly readable). */
    fun candidatesLikelyNeedingSaf(): List<WhatsAppMediaPath> =
        knownRelativePaths.filterNot { it.directAccessExpected }
}
