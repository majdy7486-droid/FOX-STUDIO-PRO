package com.fox.recovery.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.fox.recovery.permissions.PermissionManager
import com.fox.recovery.recovery.ScanKind
import com.fox.recovery.ui.screens.HomeScreen
import com.fox.recovery.ui.screens.PermissionsScreen
import com.fox.recovery.ui.screens.ScanResultsScreen
import com.fox.recovery.ui.viewmodel.RecoveryViewModel
import androidx.compose.ui.platform.LocalContext

private object Routes {
    const val HOME = "home"
    const val PERMISSIONS = "permissions"
    const val RESULTS = "results/{kind}"
    fun results(kind: ScanKind) = "results/${kind.name}"
}

@Composable
fun FoxNavGraph(navController: NavHostController = rememberNavController()) {
    val viewModel: RecoveryViewModel = viewModel()
    val context = LocalContext.current

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onStartScan = { kind ->
                    if (PermissionManager.hasMediaPermissions(context)) {
                        viewModel.resetState()
                        viewModel.startScan(kind)
                        navController.navigate(Routes.results(kind))
                    } else {
                        navController.navigate(Routes.PERMISSIONS)
                    }
                },
                onOpenPermissions = { navController.navigate(Routes.PERMISSIONS) }
            )
        }
        composable(Routes.PERMISSIONS) {
            PermissionsScreen(onGranted = { navController.popBackStack() })
        }
        composable(Routes.RESULTS) { backStackEntry ->
            val kindName = backStackEntry.arguments?.getString("kind")
            // kindName is only used to restart a scan if the user re-enters
            // this route directly (e.g. process recreation); normal
            // navigation already triggered the scan from HomeScreen above.
            val progress by viewModel.progress.collectAsState()
            if (kindName != null) {
                ScanResultsScreen(progress = progress)
            }
        }
    }
}
