package com.fox.recovery.recovery

import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A local WhatsApp backup database file found on the device. */
data class BackupFileInfo(
    val file: File,
    val sizeBytes: Long,
    val lastModified: Long,
    val encryptionScheme: String,   // e.g. "crypt14", "crypt15", "crypt12", "unknown"
    val containsMediaReferencesOnly: Boolean // true: message DB, references media but doesn't hold the bytes
)

/** Overall availability/limits for the backups this device exposes. */
data class BackupAnalysisReport(
    val localBackupsFound: List<BackupFileInfo>,
    val decryptionSupported: Boolean,
    val limitationMessage: String
)

/**
 * Level 3: finds local WhatsApp backup *database* files and reports what
 * they are, without ever attempting to decrypt them or touch the originals.
 *
 * WhatsApp's local backups (msgstore.db.crypt12/14/15) are encrypted with a
 * key that is not exposed to third-party apps through any public Android
 * API. Decrypting them legitimately requires either the official
 * Google-Drive-restore flow (through WhatsApp itself) or a key the user
 * extracts themselves through WhatsApp's own export tools. This analyzer
 * intentionally stops at detection + metadata, per the project's own
 * requirement to never claim a successful restore that wasn't verified and
 * never bypass encryption (see docs/RECOVERY_LIMITATIONS.md).
 */
class BackupAnalyzer {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun analyze(): BackupAnalysisReport {
        val root = Environment.getExternalStorageDirectory()
        val candidateDirs = listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Databases"),
            File(root, "WhatsApp/Databases")
        )

        val found = candidateDirs
            .filter { it.exists() && it.isDirectory && it.canRead() }
            .flatMap { dir -> dir.listFiles { f -> f.isFile && isBackupFile(f.name) }?.toList() ?: emptyList() }
            .map { toBackupFileInfo(it) }

        return BackupAnalysisReport(
            localBackupsFound = found,
            decryptionSupported = false,
            limitationMessage = if (found.isEmpty()) {
                "No local WhatsApp backup database files were found in the checked folders."
            } else {
                "${found.size} local backup file(s) detected (last: ${found.maxByOrNull { it.lastModified }?.let { dateFormat.format(Date(it.lastModified)) }}). " +
                    "These are encrypted by WhatsApp; this app cannot and does not attempt to decrypt them. " +
                    "To restore from them, use WhatsApp's own \"Restore from local backup\" option during reinstall, " +
                    "or Google Drive restore if a cloud backup exists."
            }
        )
    }

    private fun isBackupFile(name: String): Boolean =
        name.startsWith("msgstore") && (name.contains(".crypt"))

    private fun toBackupFileInfo(file: File): BackupFileInfo {
        val scheme = Regex("crypt(\\d+)").find(file.name)?.value ?: "unknown"
        return BackupFileInfo(
            file = file,
            sizeBytes = file.length(),
            lastModified = file.lastModified(),
            encryptionScheme = scheme,
            containsMediaReferencesOnly = true
        )
    }
}
