package com.fox.recovery.recovery

import android.content.Context
import com.fox.recovery.core.filesignatures.DetectedFileType
import com.fox.recovery.core.filesignatures.FileSignatureAnalyzer
import com.fox.recovery.media.MediaStoreScanner
import com.fox.recovery.media.WhatsAppPathResolver
import com.fox.recovery.model.MediaKind
import com.fox.recovery.model.RecoverySource
import com.fox.recovery.model.RecoveryStatus
import com.fox.recovery.model.ScanResultItem
import java.io.File
import java.util.UUID

private val VIDEO_EXTENSIONS = setOf("mp4", "mov", "mkv", "3gp", "webm", "avi", "m4v")

/**
 * Level 1 video recovery. Mirrors ImageRecoveryEngine's approach but adds a
 * playability sanity check: a video container can be structurally present
 * yet have a damaged index, which this engine must NOT report as fully
 * healthy without the lightweight check below (spec: never show a recovered
 * video as sound before checking it can actually be opened).
 */
class VideoRecoveryEngine(private val context: Context) {

    private val mediaStoreScanner = MediaStoreScanner(context)

    fun scan(onFile: (Int) -> Unit = {}): List<ScanResultItem> {
        val fromMediaStore = mediaStoreScanner.scanVideos(whatsAppOnly = false, onFile = onFile)
        var processed = fromMediaStore.size

        val fromFolders = mutableListOf<ScanResultItem>()
        WhatsAppPathResolver.resolveAccessibleCandidates().forEach { dir ->
            dir.listFiles { f -> f.isFile && f.extension.lowercase() in VIDEO_EXTENSIONS }?.forEach { file ->
                val signature = FileSignatureAnalyzer.analyze(file)
                fromFolders += buildResultItem(file, signature)
                processed++
                onFile(processed)
            }
        }
        return fromMediaStore + fromFolders
    }

    private fun buildResultItem(file: File, signature: com.fox.recovery.core.filesignatures.SignatureResult): ScanResultItem {
        val playableHeaderFound = signature.detectedType in setOf(
            DetectedFileType.MP4, DetectedFileType.MOV, DetectedFileType.MKV_WEBM, DetectedFileType.THREE_GP, DetectedFileType.AVI
        )
        val status = when {
            !signature.headerReadable -> RecoveryStatus.UNVERIFIABLE
            !playableHeaderFound -> RecoveryStatus.PARTIALLY_CORRUPTED
            else -> RecoveryStatus.EXISTS_CAN_BE_COPIED
        }
        return ScanResultItem(
            id = UUID.randomUUID().toString(),
            displayName = file.name,
            kind = MediaKind.VIDEO,
            sizeBytes = file.length(),
            source = RecoverySource.EXISTING_WHATSAPP_FOLDER,
            dateAvailable = file.lastModified(),
            status = status,
            previewAvailable = playableHeaderFound,
            repairable = false, // real repair attempts are a Phase-2 item, see docs/STATUS.md
            unavailableReason = if (status == RecoveryStatus.PARTIALLY_CORRUPTED)
                "No recognizable video container header was found; the index may be damaged." else null,
            absolutePathOrUri = file.absolutePath
        )
    }
}
