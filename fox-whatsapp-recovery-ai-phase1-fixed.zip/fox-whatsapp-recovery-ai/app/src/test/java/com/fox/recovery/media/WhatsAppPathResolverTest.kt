package com.fox.recovery.media

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * NOTE: WhatsAppPathResolver calls android.os.Environment, so this test
 * needs to run as an Android instrumented/Robolectric test, not plain JVM
 * JUnit — it is placed under src/test as a reminder to wire up Robolectric
 * in Phase 2 (see docs/STATUS.md). Left here un-run rather than deleted,
 * so the intent and expected coverage are not lost.
 */
class WhatsAppPathResolverTest {

    @Test
    fun knownPathsCoverBothRegularAndBusinessVariants() {
        val variants = WhatsAppPathResolver.allCandidatePaths().map { it.first.variant }.toSet()
        assertTrue(variants.contains(WhatsAppVariant.REGULAR))
        assertTrue(variants.contains(WhatsAppVariant.BUSINESS))
    }

    @Test
    fun includesBothLegacyAndCurrentAndroidMediaLocations() {
        val relativePaths = WhatsAppPathResolver.allCandidatePaths().map { it.first.relativePath }.toSet()
        assertTrue(relativePaths.any { it.startsWith("Android/media/com.whatsapp") })
        assertTrue(relativePaths.any { it == "WhatsApp/Media" })
    }
}
